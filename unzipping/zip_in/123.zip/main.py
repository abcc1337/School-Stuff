# coding: utf-8
import os

def check(b1, b2, b):
    return (b1 * 3 + b2 * 4) == b and b1 >= 0 and b2 >= 0

if __name__ == "__main__":
    # 2
    blades = int(input())
    combinations = [blades // 3, blades // 4]
    result = [0, 0]

    while any(combinations):
        b1, b2 = combinations

        if  check(b1, b2, blades):
            result = b1, b2
            break

        if  check(b1 - 1, b2, blades):
            result = b1 - 1, b2
            break

        if  check(b1, b2 - 1, blades):
            result = b1, b2 - 1
            break

        if check(b1 - 1, b2 - 1, blades):
            result = b1 - 1, b2 - 1
            break

        combinations[1] -= 1
        combinations[0] -= 1

    print(*result, sep='\n')

    quit(0)
    # 1
    base, blade, cost = [int(input()) for _ in range(3)]
    result = (cost - base) // blade
    print(result)
